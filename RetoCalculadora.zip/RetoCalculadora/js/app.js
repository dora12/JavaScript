var Calculadora=(function() {

	var resultado=0;
	function actualizarResultado(nuevoResultado) {
		resultado=nuevoResultado
    alert(resultado)
	}
	return{
		presiona_tecla:function () {
      var idx = this.getAttribute("id");
      document.getElementById(idx).setAttribute("style","transform:scale(0.85,0.85)")
      obj1.validadisplay(idx);
		},

    retira_tecla:function () {
      var idx = this.getAttribute("id");
      document.getElementById(idx).setAttribute("style","transform:scale(1,1)")
		},

    validadisplay:function (idx) {

      anterior=document.getElementById('display').innerHTML;
      if (anterior.length==1 && anterior==0 ) {
        numeros="0123456789";
        if (numeros.indexOf(idx)==-1) {idx="";}else{anterior="";}
      }

        switch (idx) {
        case "mas":
                  idx="+";break;
        case "menos":
                  idx="-";break;
        case "por":
                  idx="*";break;
        case "dividido":
                  if (anterior.length==1 && anterior==0 ) {idx="";alert("Imposible division para 0")}
                  else {idx="/";}break;
        case "sign":
                  var valsing=document.getElementById('display').innerHTML;
                  if (valsing>0) {idx="-";}
                  else {idx="";}
                  anterior=document.getElementById('display').innerHTML;
                  idx=idx+Math.abs(anterior);anterior=" ";break;
        case "raiz":
                  idx="";break;
        case "punto":
                  idx=".";
                  for (var a = 0; a < anterior.length; a++) {
                    if (anterior.charAt(a)=="." && igual>1) {idx="";}
                  }break;
        case "on":
                  idx="0";anterior=0;
                  document.getElementById('display').innerHTML="0";break;
        case "igual":
                anterior=document.getElementById('display').innerHTML;
                idx="";var idx=eval(anterior);anterior=" ";break;
        default:
      }

      if (anterior.charAt(anterior.length-1)=="+" || anterior.charAt(anterior.length-1)=="-" || anterior.charAt(anterior.length-1)=="*" || anterior.charAt(anterior.length-1)=="/" ) {
        letra=anterior.charAt(anterior.length-1);
        numeros="0123456789";
        if (letra && numeros.indexOf(idx)==-1) {idx="";}
      }

      if (anterior.length<8) {document.getElementById('display').innerHTML=anterior+idx;}

		},

		restar:function () {
			var resultado=num1-num2
			actualizarResultado(resultado)
		},

		resultado:function () {
			return resultado
		}
	}
});


var obj1 = Calculadora();

var x = document.getElementsByClassName("tecla");
for (var i = 0; i < x.length; i++) {
  x[i].addEventListener('mousedown',obj1.presiona_tecla);
  x[i].addEventListener('mouseout', obj1.retira_tecla);

}
